"use strict";
cc._RF.push(module, '68b83d4K1VMXL/okU5vbdFS', 'RoomScene');
// Script/RoomScene.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        m_BtAction: [cc.Node],
        m_BtPlayerInfo: [cc.Node],
        m_MainView: cc.Node,
        m_SelPlayerView: cc.Node
    },
    // use this for initialization
    onLoad: function onLoad() {
        this.m_MainView.setPosition(0, 0);
        this.m_SelPlayerView.active = false;
        this.btStartPos = new Array();
        for (var i = 0; i < this.m_BtAction.length; i++) {
            this.btStartPos[i] = this.m_BtAction[i].getPosition();
        }

        for (var i = 0; i < this.m_BtPlayerInfo.length; i++) {
            var sprite = this.m_BtPlayerInfo[i].getChildByName('Pressed');
            sprite.active = false;
            this.m_BtPlayerInfo[i].on(cc.Node.EventType.TOUCH_START, this.touchShowTexture, this);
            this.m_BtPlayerInfo[i].on(cc.Node.EventType.TOUCH_END, this.touchHideTexture, this);
            this.m_BtPlayerInfo[i].on(cc.Node.EventType.TOUCH_CANCEL, this.touchHideTexture, this);
        }
    },
    touchShowTexture: function touchShowTexture(target) {
        // this.m_MountTexture.node.active = true;
        var sprite = target.target.getChildByName('Pressed');
        sprite.active = true;
    },
    touchHideTexture: function touchHideTexture(target) {
        // this.m_MountTexture.node.active = false;

        var sprite = target.target.getChildByName('Pressed');
        sprite.active = false;
    },
    onChangeScene: function onChangeScene() {
        cc.director.loadScene("GameScene");
    },
    onActionBtOutOrIn: function onActionBtOutOrIn(Out) {
        for (var i = 0; i < this.m_BtAction.length; i++) {
            var delaTime = cc.delayTime(0.1 * i);
            var moveTo;
            if (Out) {
                moveTo = cc.moveTo(0.3, cc.p(350, this.btStartPos[i].y));
            } else {
                moveTo = cc.moveTo(0.3, this.btStartPos[i]);
            }
            var sql = cc.sequence(delaTime, moveTo);
            this.m_BtAction[i].runAction(sql);
        }
    },
    onOpenPlayerView: function onOpenPlayerView() {

        this.m_MainView.active = false;
        this.m_SelPlayerView.active = true;
    },
    onOpenMainView: function onOpenMainView() {
        this.m_MainView.active = true;
        this.m_SelPlayerView.active = false;
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();