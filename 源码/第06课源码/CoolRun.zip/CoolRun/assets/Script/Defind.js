var BackMoveTime1 = 30;
var BackMoveTime2 = 30;
var BackMoveTime3 = 20;
var BackMoveTime4 = 20;
var BackMoveTime5 = 5;
var FloorMoveTime1 = 3;