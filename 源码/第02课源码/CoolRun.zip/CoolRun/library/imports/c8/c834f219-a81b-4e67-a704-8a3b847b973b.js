"use strict";
cc._RF.push(module, 'c834fIZqBtOZ6cEijuEe5c7', 'BaseVIew');
// Script/BaseVIew.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        m_Hero: cc.Animation
    },

    // use this for initialization
    //第一次进入,空间创建产生后会调用的函数
    onLoad: function onLoad() {
        // cc.log('Hello World');
        // this.m_Hero = this.m_Hero.getComponent(cc.Animation);
        this.m_Hero.play('Run');
    },

    onAnimationChange: function onAnimationChange(target, data) {
        cc.log("onAnimationChange " + data);
        this.m_Hero.play(data);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();