(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/BaseVIew.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'c834fIZqBtOZ6cEijuEe5c7', 'BaseVIew', __filename);
// Script/BaseVIew.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        m_Hero: cc.Animation
    },

    // use this for initialization
    //第一次进入,空间创建产生后会调用的函数
    onLoad: function onLoad() {
        // cc.log('Hello World');
        // this.m_Hero = this.m_Hero.getComponent(cc.Animation);
        this.m_Hero.play('Run');
    },

    onAnimationChange: function onAnimationChange(target, data) {
        cc.log("onAnimationChange " + data);
        this.m_Hero.play(data);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=BaseVIew.js.map
        