"use strict";
cc._RF.push(module, '68b83d4K1VMXL/okU5vbdFS', 'RoomScene');
// Script/RoomScene.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        m_BtAction: [cc.Node]
    },
    // use this for initialization
    onLoad: function onLoad() {
        this.btStartPos = new Array();
        for (var i = 0; i < this.m_BtAction.length; i++) {
            this.btStartPos[i] = this.m_BtAction[i].getPosition();
        }
    },
    onChangeScene: function onChangeScene() {
        cc.director.loadScene("GameScene");
    },
    onActionBtOutOrIn: function onActionBtOutOrIn(Out) {
        for (var i = 0; i < this.m_BtAction.length; i++) {
            var delaTime = cc.delayTime(0.1 * i);
            var moveTo;
            if (Out) {
                moveTo = cc.moveTo(0.3, cc.p(350, this.btStartPos[i].y));
            } else {
                moveTo = cc.moveTo(0.3, this.btStartPos[i]);
            }
            var sql = cc.sequence(delaTime, moveTo);
            this.m_BtAction[i].runAction(sql);
        }
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();