(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/RoomScene.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '68b83d4K1VMXL/okU5vbdFS', 'RoomScene', __filename);
// Script/RoomScene.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        m_BtAction: [cc.Node]
    },
    // use this for initialization
    onLoad: function onLoad() {
        this.btStartPos = new Array();
        for (var i = 0; i < this.m_BtAction.length; i++) {
            this.btStartPos[i] = this.m_BtAction[i].getPosition();
        }
    },
    onChangeScene: function onChangeScene() {
        cc.director.loadScene("GameScene");
    },
    onActionBtOutOrIn: function onActionBtOutOrIn(Out) {
        for (var i = 0; i < this.m_BtAction.length; i++) {
            var delaTime = cc.delayTime(0.1 * i);
            var moveTo;
            if (Out) {
                moveTo = cc.moveTo(0.3, cc.p(350, this.btStartPos[i].y));
            } else {
                moveTo = cc.moveTo(0.3, this.btStartPos[i]);
            }
            var sql = cc.sequence(delaTime, moveTo);
            this.m_BtAction[i].runAction(sql);
        }
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=RoomScene.js.map
        