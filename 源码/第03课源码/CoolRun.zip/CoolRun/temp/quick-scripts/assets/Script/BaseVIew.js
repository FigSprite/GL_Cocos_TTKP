(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/BaseVIew.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'c834fIZqBtOZ6cEijuEe5c7', 'BaseVIew', __filename);
// Script/BaseVIew.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        m_Hero: cc.Animation,
        m_BtRoll: cc.Button
    },

    // use this for initialization
    //第一次进入,空间创建产生后会调用的函数
    onLoad: function onLoad() {
        // cc.log('Hello World');
        // this.m_Hero = this.m_Hero.getComponent(cc.Animation);
        this.myHeroPlay('Run');
        this.m_BtRoll.node.on(cc.Node.EventType.TOUCH_START, this.touchStart, this);
        this.m_BtRoll.node.on(cc.Node.EventType.TOUCH_END, this.touchEnd, this);
        this.m_BtRoll.node.on(cc.Node.EventType.TOUCH_CANCEL, this.touchEnd, this);
    },
    touchStart: function touchStart() {
        cc.log('touchStart');
        if (this.m_Hero.currentClip.name == 'Jump') {
            return;
        }
        this.myHeroPlay('Roll');
    },
    touchEnd: function touchEnd() {
        cc.log('touchEnd');
        if (this.m_Hero.currentClip.name == 'Jump') {
            return;
        }
        this.myHeroPlay('Run');
    },
    callBackDownOver: function callBackDownOver() {
        cc.log('callBackDownOver');
        // var anim = this.getComponent(cc.Animation);
        this.myHeroPlay('Run');
    },
    onAnimationChange: function onAnimationChange(target, data) {
        cc.log("onAnimationChange " + data);

        if (data == 'Jump') {
            var moveUp = cc.moveTo(1, -92, 42).easing(cc.easeCubicActionOut());
            var moveDown = cc.moveTo(1, -92, -52).easing(cc.easeCubicActionIn());
            var callBack = cc.callFunc(this.callBackDownOver, this, this);
            var seq = cc.sequence(moveUp, moveDown, callBack);
            this.m_Hero.node.runAction(seq);
        }
        this.myHeroPlay(data);
    },
    myHeroPlay: function myHeroPlay(playName) {
        if (playName == 'Roll') {
            this.m_Hero.node.setPosition(-92, -57);
        } else if (playName == 'Run') {
            this.m_Hero.node.setPosition(-92, -49);
        }
        this.m_Hero.play(playName);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=BaseVIew.js.map
        