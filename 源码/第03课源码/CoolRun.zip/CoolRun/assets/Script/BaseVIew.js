cc.Class({
    extends: cc.Component,

    properties: {
        m_Hero:cc.Animation,
        m_BtRoll:cc.Button,
    },

    // use this for initialization
    //第一次进入,空间创建产生后会调用的函数
    onLoad: function () {
        // cc.log('Hello World');
        // this.m_Hero = this.m_Hero.getComponent(cc.Animation);
        this.myHeroPlay('Run');
        this.m_BtRoll.node.on(cc.Node.EventType.TOUCH_START,this.touchStart,this);
        this.m_BtRoll.node.on(cc.Node.EventType.TOUCH_END,this.touchEnd,this);
        this.m_BtRoll.node.on(cc.Node.EventType.TOUCH_CANCEL,this.touchEnd,this);
    },
    touchStart:function()
    {
        cc.log('touchStart');
        if(this.m_Hero.currentClip.name == 'Jump' )
        {
            return;
        }
        this.myHeroPlay('Roll');
    },
    touchEnd:function()
    {
        cc.log('touchEnd');
        if(this.m_Hero.currentClip.name == 'Jump' )
        {
            return;
        }
        this.myHeroPlay('Run');
    },
    callBackDownOver:function()
    {
        cc.log('callBackDownOver');
        // var anim = this.getComponent(cc.Animation);
        this.myHeroPlay('Run');
    },
    onAnimationChange:function(target,data)
    {
        cc.log("onAnimationChange "+data);

        if( data == 'Jump')
        {
            var moveUp = cc.moveTo(1,-92,42).easing(cc.easeCubicActionOut());
            var moveDown = cc.moveTo(1,-92,-52).easing(cc.easeCubicActionIn());
            var callBack = cc.callFunc(this.callBackDownOver,this,this);
            var seq = cc.sequence(moveUp,moveDown,callBack); 
            this.m_Hero.node.runAction(seq);
        }
        this.myHeroPlay(data);
    },
    myHeroPlay:function(playName)
    {
        if( playName == 'Roll' )
        {
            this.m_Hero.node.setPosition(-92,-57);
        }
        else if( playName == 'Run')
        {
            this.m_Hero.node.setPosition(-92,-49);

        }
        this.m_Hero.play(playName);
    },
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
